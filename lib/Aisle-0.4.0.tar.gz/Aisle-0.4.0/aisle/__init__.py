from aisle.init import LOG
from aisle.utils import LogMixin, CliHelper
from aisle.config import *
#TODO:添加全局日志等级的配置，把这个包做成一个类
